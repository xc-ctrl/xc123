#include <stdio.h>
#include <stdbool.h>

#include "los_task.h"
#include "ohos_init.h"
#include "cmsis_os.h"
#include "config_network.h"
#include "lcd.h"
#include"intelligent_medicine_box.h"
#include"sht30.h"
#include "mq2.h"
#include "bh1750.h"
#include "adc_key.h"
#include "medicine_box_event.h"
#include "iot.h"
#include "su_03t.h"
#include "iot_i2c.h"


#define ROUTE_SSID      "Mi 11 Lite"          // WiFi账号
#define ROUTE_PASSWORD "xxc060707@"       // WiFi密码

#define MSG_QUEUE_LENGTH                                16
#define BUFFER_LEN                                      50

extern int medicine_flag;


/***************************************************************
 * 函数名称: iot_thread
 * 说    明: iot线程
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/
void iot_thread(void *args) {
  uint8_t mac_address[12] = {0x00, 0xdc, 0xb6, 0x90, 0x01, 0x00,0};

  char ssid[32]=ROUTE_SSID;
  char password[32]=ROUTE_PASSWORD;
  char mac_addr[32]={0};

  FlashDeinit();
  FlashInit();

  VendorSet(VENDOR_ID_WIFI_MODE, "STA", 3); // 配置为Wifi STA模式
  VendorSet(VENDOR_ID_MAC, mac_address, 6); // 多人同时做该实验，请修改各自不同的WiFi MAC地址
  VendorSet(VENDOR_ID_WIFI_ROUTE_SSID, ssid, sizeof(ssid));
  VendorSet(VENDOR_ID_WIFI_ROUTE_PASSWD, password,sizeof(password));

reconnect:
  SetWifiModeOff();
  int ret = SetWifiModeOn();
  if(ret != 0){
    printf("wifi connect failed,please check wifi config and the AP!\n");
    return;
  }
  mqtt_init();

  while (1) {
    if (!wait_message()) {
      goto reconnect;
    }
    LOS_Msleep(1);
  }
}



float g_humi;
float g_temp;
float g_ppm;
float g_bh;

static unsigned int m_msg_queue;
unsigned int m_su03_msg_queue;

bool motor_state = false;
bool light_state = false;
bool auto_state = false;
double *data_ptr = NULL;

static int s = 53;
static int m = 10;
static int h = 1;

/***************************************************************
 * 函数名称: intelligent_medicine_box_thread
 * 说    明: 智能药盒主线程
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/

 void intelligent_medicine_box_thread(void *arg)
 {
        double sht30_data[2]={0};//用于存储温度和湿度的数据
        double read_data[2] = {0};
        

       lcd_dev_init();
       sht30_init();
        mq2_init();
        body_induction_dev_init();
        bh1750_init();
        lcd_show();
        light_dev_init();
        su03t_init();
       HW_INIT();//hw初始化


        
        while (1)
    {


      if (!auto_state)
        {
            light_set_state(light_state);
        }
        /*时间*/
        s = s + 1;
        if (s == 59)
        {
            s = 0;
            m = m + 1;
            if (h == 59)
            {
                m = 0;
                h = h +1;
            }
        }
        //lcd_show_int_num(248, 8, s,2, LCD_BLACK, LCD_WHITE, 16);
        lcd_show_int_num(224, 8, m,2, LCD_BLACK, LCD_WHITE, 16);
        lcd_show_int_num(200, 8, h,2, LCD_BLACK, LCD_WHITE, 16); 



        sht30_read_data(sht30_data);
        mq2_read_data(&read_data[0]);
        bh1750_read_data(&read_data[1]);
        //printf("temperature %.2f RH %.2f \r\n", sht30_data[0], sht30_data[1]);


        g_temp = sht30_data[0];
        g_humi = sht30_data[1];//湿度
        g_ppm =read_data[0];//烟雾
        g_bh =read_data[1];//光照
        
      lcd_load();


       ///lcd_show_chinese(5,58,"温度",LCD_RED,LCD_WHITE,24,0);
        lcd_show_int_num(48,40,g_temp,2,LCD_RED,LCD_WHITE,16);
        lcd_show_float_num1(64,40,g_temp,2,LCD_RED,LCD_WHITE,16);

       // lcd_show_chinese(5,82,"湿度",LCD_RED,LCD_WHITE,24,0);
        lcd_show_int_num(48,64,g_humi,2,LCD_RED,LCD_WHITE,16);
        lcd_show_float_num1(64,64,g_humi,2,LCD_RED,LCD_WHITE,16);

        //lcd_show_chinese(5,106,"烟雾",LCD_RED,LCD_WHITE,24,0);
       // lcd_show_int_num(80,106,g_ppm,2,LCD_RED,LCD_WHITE,24);
        //lcd_show_float_num1(130,106,g_ppm,2,LCD_RED,LCD_WHITE,24);

       // body_induction_lcd_express();

        //lcd_show_chinese(5,155,"光照为",LCD_RED,LCD_WHITE,16,0);
        lcd_show_int_num(72,112,g_bh,3,LCD_RED,LCD_WHITE,16);
        
        if(g_ppm<25){
          g_ppm =true;
          lcd_show_chinese(72,88,"正常",LCD_RED,LCD_WHITE,16,0);
        } else{
          g_ppm =false;
          lcd_show_chinese(72,88,"过浓",LCD_RED,LCD_WHITE,16,0);
        }


        



        //多任务选择
        

       event_info_t event_info = {0};
       //等待事件触发,如有触发,则立即处理对应事件,如未等到,则执行默认的代码逻辑,更新屏幕
       int ret = medicine_box_event_wait(&event_info,3000);
       //printf("medicine_box_event_wait ret=%d\n", ret); // 添加调试打印
      if(ret == LOS_OK){
         //收到指令

            switch (event_info.event)
            {
              case event_key_press:
                  medicine_key_process(event_info.data.key_no);

                  break;

              case event_iot_cmd:
                  medicine_iot_cmd_process(event_info.data.iot_data);
                  break;

              default:break;
            }

      }



        //iot代码


        e_iot_data iot_data = {0};




        if(mqtt_is_connected())
        {
          iot_data.illumination = g_bh;
          iot_data.temperature = g_temp;
          iot_data.humidity = g_humi;
          iot_data.smoke_state =g_ppm;
          //printf("medicine_flag=%d",medicine_flag);
         // printf("iot_data.medicine_state=%d",iot_data.medicine_state);

          iot_data.medicine_state = medicine_flag;
         // printf("iot_data.medicine_state=%d",iot_data.medicine_state);

          send_msg_to_mqtt(&iot_data);//会把数据传到iot代码上，再上传到iot




        }

        //红外对管
        uint16_t value1,value2,value3,value4;
        value1 =HW_GetData_1();
        value2 =HW_GetData_2();
        value3 =HW_GetData_3();
        value4 =HW_GetData_4();
        if(value1){
          lcd_show_chinese(85,208,"正常",LCD_RED,LCD_WHITE,16,0);
          printf("value1是1\r\n");
        }else if(!value1){
          lcd_show_chinese(85,208,"过少",LCD_RED,LCD_WHITE,16,0);
          printf("value1是0\r\n");
        }
         if(value2){
          
         lcd_show_chinese(85,184,"正常",LCD_RED,LCD_WHITE,16,0);
          printf("value2是1\r\n");
        }else if(!value2){
          lcd_show_chinese(85,184,"正常",LCD_RED,LCD_WHITE,16,0);
          
          printf("value2是0\r\n");
        }
         if(value3){
        lcd_show_chinese(85,136,"正常",LCD_RED,LCD_WHITE,16,0);  
          
          printf("value3是1\r\n");
        }else if(!value3){
        lcd_show_chinese(85,136,"过少",LCD_RED,LCD_WHITE,16,0); 
        
          printf("value3是0\r\n");
        }
        if(value4){
          lcd_show_chinese(85,160,"正常",LCD_RED,LCD_WHITE,16,0);
          
          printf("value4是1\r\n");
        }else if(!value4){
         lcd_show_chinese(85,160,"过少",LCD_RED,LCD_WHITE,16,0);
        
          printf("value4是0\r\n");
        }
        





        LOS_Msleep(500);
    }



 }


/***************************************************************
* 函数名称: device_read_thraed
* 说    明: 
* 参    数: 无
* 返 回 值: 无
***************************************************************/
//占空比整形,让占空比处于1~99之间
void device_read_thraed(void *arg)
{
    double read_data[3] = {0};
    int count =0;
    i2c_dev_init();
    while (1)
    { 
        bh1750_read_data(&read_data[2]);
        sht30_read_data(read_data);
        LOS_QueueWrite(m_su03_msg_queue, (void *)&read_data, sizeof(read_data), LOS_WAIT_FOREVER );
        LOS_Msleep(1000);
    }
}


 /***************************************************************
 * 函数名称:  iot_intelligent_medicine_box_example
 * 说    明: 开机自启动调用函数
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/
void iot_intelligent_medicine_box_example()
{
    unsigned int thread_id_1;
    unsigned int thread_id_2;
    unsigned int thread_id_3;
    unsigned int thread_id_4;
    TSK_INIT_PARAM_S task_1 = {0};
    TSK_INIT_PARAM_S task_2 = {0};
    TSK_INIT_PARAM_S task_3 = {0};
    TSK_INIT_PARAM_S task_4 = {0};
    unsigned int ret = LOS_OK;

    medicine_box_event_init();

    task_1.pfnTaskEntry = (TSK_ENTRY_FUNC)intelligent_medicine_box_thread;
    task_1.uwStackSize = 2048;
    task_1.pcName = "intelligent_medicine_box_thread";
    task_1.usTaskPrio = 20;
    ret = LOS_TaskCreate(&thread_id_1,&task_1);
    if (ret != LOS_OK)
    {
        printf("Falied to create task ret:0x%x\n", ret);
        return;
    }

    task_2.pfnTaskEntry = (TSK_ENTRY_FUNC)adc_key_thread;
    task_2.uwStackSize = 2048;
    task_2.pcName = "key thread";
    task_2.usTaskPrio = 20;
    ret = LOS_TaskCreate(&thread_id_2, &task_2);
    if (ret != LOS_OK)
    {
        printf("Falied to create task ret:0x%x\n", ret);
        return;
    }

    task_3.pfnTaskEntry = (TSK_ENTRY_FUNC)iot_thread;
    task_3.uwStackSize = 20480*5;
    task_3.pcName = "iot thread";
    task_3.usTaskPrio = 20;
    ret = LOS_TaskCreate(&thread_id_3, &task_3);
    if (ret != LOS_OK)
    {
        printf("Falied to create task ret:0x%x\n", ret);
        return;
    }

    task_4.pfnTaskEntry = (TSK_ENTRY_FUNC)device_read_thraed;
    task_4.uwStackSize = 2048;
    task_4.pcName = "device read thread";
    task_4.usTaskPrio = 20;
    ret = LOS_TaskCreate(&thread_id_4, &task_4);
    if (ret != LOS_OK)
    {
        printf("Falied to create task ret:0x%x\n", ret);
        return;

}

}
APP_FEATURE_INIT(iot_intelligent_medicine_box_example);