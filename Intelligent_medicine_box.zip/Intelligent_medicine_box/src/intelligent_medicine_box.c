#include "intelligent_medicine_box.h"

#include <stdio.h>
#include <stdbool.h>

#include "iot_pwm.h"
#include "iot_gpio.h"
#include "lcd.h"
#include"sht30.h"
#include "mq2.h"

#include "adc_key.h"
#include "iot.h"
#include "medicine_box_event.h"
#include "iot_i2c.h"

#define GPIO_BODY_INDUCTION GPIO0_PA3


/***************************************************************
* 函数名称: lcd_dev_init
* 说    明: lcd初始化
* 参    数: 无
* 返 回 值: 无
***************************************************************/
void lcd_dev_init(void)
{
    lcd_init();
    lcd_fill(0, 0, LCD_W, LCD_H, LCD_WHITE);
}





/***************************************************************
 * 函数名称: mq2_init
 * 说    明: mq2初始化
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/
void mq2_init(void)
{
    mq2_dev_init();  //初始化ADC
    mq2_ppm_calibration(); //传感器校准函数
}

/***************************************************************
 * 函数名称: mq2_read_data
 * 说    明: 读取mq2传感器数据
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/
void mq2_read_data(double *dat)
{
    *dat = get_mq2_ppm();
}


/***************************************************************
 * 函数名称: body_induction_dev_init
 * 说    明: 人体感应传感器初始化
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/
void body_induction_dev_init()
{
    IoTGpioInit(GPIO_BODY_INDUCTION);
    IoTGpioSetDir(GPIO_BODY_INDUCTION, IOT_GPIO_DIR_IN);
}

/***************************************************************
 * 函数名称: body_induction_lcd_express
 * 说    明: lcd表示人体感应状态
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/
void body_induction_lcd_express()
{
    IotGpioValue value = IOT_GPIO_VALUE0;

    IoTGpioGetInputVal(GPIO_BODY_INDUCTION, &value);

    if (value) 
    {
       
        lcd_show_chinese(5,135,"有人",LCD_RED,LCD_WHITE,16,0);
    }
    else
    {
        
        lcd_show_chinese(5,135,"无人",LCD_RED,LCD_WHITE,16,0);
    }
}



/*
*************************
*************************
*/

static uint32_t key_down_start_time = 0;
//static uint32_t Medication_status =0; 
#define KEY_LONG_PRESS_TIME 2000  // 2秒 = 2000ms
e_iot_data iot_data ={0};

int medicine_flag=1;//标志位，上传服药状态信息

void medicine_key_process(int key_no)
{
   printf("medicine_box_process:%d\n",key_no);
    if(key_no == KEY_UP){

     iot_data.medicine_state=2;//手动重置，上传状态为正常normal
      medicine_flag =2;
    printf("medicine_state是%d",iot_data.medicine_state);
    }else if(key_no == KEY_DOWN){

    key_down_start_time = LOS_TickCountGet();  // 记录按下开始时间
        
     while (1){
        uint32_t current_time = LOS_TickCountGet();
        if((current_time - key_down_start_time )>=(KEY_LONG_PRESS_TIME / 10))//按下超过2秒,taking
        {
            iot_data.medicine_state = true;
            medicine_flag =1;
            printf("medicine_state是%d",iot_data.medicine_state);
            current_time = 0;
            key_down_start_time = current_time;  // 更新时间，避免重复触发
            lcd_fill(160, 32, 320, 224, LCD_WHITE);;

            break;
        }

     }
    
    }else if(key_no == KEY_LEFT){
        
       
    }else if(key_no == KEY_RIGHT){
     
        
    }


}


void medicine_iot_cmd_process(int iot_cmd)//服药控制，每一次要服什么药就会亮什么颜色的方形
{
    event_info_t event={0};
    printf("进入服药控制中 \r\n");
    switch (iot_cmd)
    {
    case IOT_CMD_ARRY :
        printf("event.data.arry_data是%s",event.data.arry_data);
        break;

        case IOT_CMD_LIGHT_ON:
            lcd_fill(160, 32, 240, 128, LCD_RED);
            lcd_fill(240, 32, 320, 128, LCD_WHITE);
            lcd_fill(240, 128, 320, 224, LCD_WHITE);
            lcd_fill(160, 128, 240, 224, LCD_WHITE);

            break;
        case IOT_CMD_LIGHT_OFF:
            lcd_fill(160, 32, 320, 224, LCD_WHITE);
            
            break;    


        case IOT_CMD_YELLOW_ON:
            lcd_fill(160, 32, 240, 128, LCD_WHITE);
            lcd_fill(240, 32, 320, 128, LCD_YELLOW);
            lcd_fill(240, 128, 320, 224, LCD_WHITE);
            lcd_fill(160, 128, 240, 224, LCD_WHITE);

            break;
        case IOT_CMD_YELLOW_OFF:
            lcd_fill(160, 32, 320, 224, LCD_WHITE);
            
            break;    


        case IOT_CMD_BLUE_ON:
            lcd_fill(160, 32, 240, 128, LCD_WHITE);
            lcd_fill(240, 32, 320, 128, LCD_WHITE);
            lcd_fill(240, 128, 320, 224, LCD_WHITE);
            lcd_fill(160, 128, 240, 224, LCD_BLUE);

            break;
        case IOT_CMD_BLUE_OFF:
            lcd_fill(160, 32, 320, 224, LCD_WHITE);
            
            break;    
            
            
        case IOT_CMD_GREEN_ON:
            lcd_fill(160, 32, 240, 128, LCD_WHITE);
            lcd_fill(240, 32, 320, 128, LCD_WHITE);
            lcd_fill(240, 128, 320, 224, LCD_GREEN);
            lcd_fill(160, 128, 240, 224, LCD_WHITE);

            break;
        case IOT_CMD_GREEN_OFF:
            lcd_fill(160, 32, 320, 224, LCD_WHITE);
            
            break;    
            
            
    default:
     printf("进入服药控制default \r\n");
        break;
    }



}




//红外对管
#define GPIO_HW_1 GPIO0_PB6
#define GPIO_HW_2 GPIO0_PC2
#define GPIO_HW_3 GPIO0_PB0
#define GPIO_HW_4 GPIO0_PB1


void HW_INIT()
{
    IoTGpioInit(GPIO_HW_1);
    IoTGpioSetDir(GPIO_HW_1,IOT_GPIO_DIR_IN);

    IoTGpioInit(GPIO_HW_2);
    IoTGpioSetDir(GPIO_HW_2,IOT_GPIO_DIR_IN);

    IoTGpioInit(GPIO_HW_3);
    IoTGpioSetDir(GPIO_HW_3,IOT_GPIO_DIR_IN);

    IoTGpioInit(GPIO_HW_4);
    IoTGpioSetDir(GPIO_HW_4,IOT_GPIO_DIR_IN);

}

uint16_t HW_GetData_1(void)
{
    IotGpioValue value = IOT_GPIO_VALUE0;
    IoTGpioGetInputVal(GPIO_HW_1, &value);       // 读取输入值
    return !value;   // 1表示遇到障碍，0表示无障碍
}

uint16_t HW_GetData_2(void)
{
    IotGpioValue value = IOT_GPIO_VALUE0;
    IoTGpioGetInputVal(GPIO_HW_2, &value);       // 读取输入值
    return !value;   // 1表示遇到障碍，0表示无障碍
}

uint16_t HW_GetData_3(void)
{
    IotGpioValue value = IOT_GPIO_VALUE0;
    IoTGpioGetInputVal(GPIO_HW_3, &value);       // 读取输入值
    return !value;   // 1表示遇到障碍，0表示无障碍
}

uint16_t HW_GetData_4(void)
{
    IotGpioValue value = IOT_GPIO_VALUE0;
    IoTGpioGetInputVal(GPIO_HW_4, &value);       // 读取输入值
    return !value;   // 1表示遇到障碍，0表示无障碍
}


void lcd_load(void)
    {
        lcd_show_chinese(16, 0,"智能药盒" , LCD_BLACK, LCD_WHITE, 32, 0);
        lcd_show_chinese(0, 40,"温度" , LCD_RED, LCD_WHITE, 16, 0);
        lcd_show_string(32, 40, ":", LCD_BLACK, LCD_WHITE, 16, 0);
        lcd_show_chinese(88, 40, "℃", LCD_RED, LCD_WHITE, 16, 0);
        lcd_show_chinese(0, 64,"湿度" , LCD_RED, LCD_WHITE, 16, 0);
        lcd_show_string(32, 64, ":", LCD_BLACK, LCD_WHITE, 16, 0);
        lcd_show_string(88, 64, "%", LCD_RED, LCD_WHITE, 16, 0);
        lcd_show_chinese(0, 88,"气体检测" , LCD_RED, LCD_WHITE, 16, 0);
        lcd_show_string(64, 88, ":", LCD_BLACK, LCD_WHITE, 16, 0);
        lcd_show_chinese(0, 112,"光照强度" , LCD_RED, LCD_WHITE, 16, 0);
        lcd_show_string(64, 112, ":", LCD_BLACK, LCD_WHITE, 16, 0);
        lcd_show_string(96, 112, "lux", LCD_RED, LCD_WHITE, 16, 0);
        lcd_show_string(160, 8, "Time:", LCD_BLACK, LCD_WHITE, 16, 0);
        lcd_show_chinese(0, 136,"药物余量" , LCD_RED, LCD_WHITE, 16, 0);
        lcd_show_string(64, 136, "R:", LCD_BLACK, LCD_WHITE, 16, 0);
        lcd_show_chinese(0, 160,"药物余量" , LCD_RED, LCD_WHITE, 16, 0);
        lcd_show_string(64, 160, "G:", LCD_BLACK, LCD_WHITE, 16, 0);
        lcd_show_chinese(0, 184,"药物余量" , LCD_RED, LCD_WHITE, 16, 0);
        lcd_show_string(64, 184, "B:", LCD_BLACK, LCD_WHITE, 16, 0);
        lcd_show_chinese(0, 208,"药物余量" , LCD_RED, LCD_WHITE, 16, 0);
        lcd_show_string(64, 208, "Y:", LCD_BLACK, LCD_WHITE, 16, 0);
        //lcd_show_chinese(0, 224,"紧急联系人" , LCD_RED, LCD_WHITE, 16, 0);
        lcd_show_string(216, 8, ":", LCD_BLACK, LCD_WHITE, 16, 0);

    }


 void lcd_show(void)
    { 
        //LOS_MuxPend(g_lcdMuxId, LOS_WAIT_FOREVER);
        lcd_fill(160, 32, 240, 128, LCD_RED);
        lcd_fill(240, 32, 320, 128, LCD_YELLOW);
        lcd_fill(240, 128, 320, 224, LCD_GREEN);
        lcd_fill(160, 128, 240, 224, LCD_BLUE);
        //LOS_MuxPost(g_lcdMuxId);
    }

    
#define I2C_HANDLE EI2C0_M2
#define LED_R_GPIO_HANDLE GPIO0_PB5
#define LED_G_GPIO_HANDLE GPIO0_PB4
#define LED_B_GPIO_HANDLE GPIO1_PD0
#define MOTOR_PWM_HANDLE EPWMDEV_PWM6_M0

 /***************************************************************
    * 函数名称: i2c_dev_init
    * 说    明: i2c设备初始化
    * 参    数: 无
    * 返 回 值: 无
    ***************************************************************/
    void i2c_dev_init(void)
    {
        IoTI2cInit(I2C_HANDLE, EI2C_FRE_400K);
        sht30_init();
        bh1750_init();
    }
    void light_dev_init(void)
    {
        IoTGpioInit(LED_R_GPIO_HANDLE);
        IoTGpioInit(LED_G_GPIO_HANDLE);
        IoTGpioInit(LED_B_GPIO_HANDLE);
        IoTGpioSetDir(LED_R_GPIO_HANDLE, IOT_GPIO_DIR_OUT);
        IoTGpioSetDir(LED_G_GPIO_HANDLE, IOT_GPIO_DIR_OUT);
        IoTGpioSetDir(LED_B_GPIO_HANDLE, IOT_GPIO_DIR_OUT);
    }

    /***************************************************************
    * 函数名称: light_set_state
    * 说    明: 控制灯状态
    * 参    数: bool state true：打开 false：关闭
    * 返 回 值: 无
    ***************************************************************/
    void light_set_state(bool state)
    {
        static bool last_state = false;

        if (state == last_state)
        {
            return;
        }

        if (state)
        {
            IoTGpioSetOutputVal(LED_R_GPIO_HANDLE, IOT_GPIO_VALUE1);
            IoTGpioSetOutputVal(LED_G_GPIO_HANDLE, IOT_GPIO_VALUE1);
            IoTGpioSetOutputVal(LED_B_GPIO_HANDLE, IOT_GPIO_VALUE1);
        }
        else
        {
            IoTGpioSetOutputVal(LED_R_GPIO_HANDLE, IOT_GPIO_VALUE0);
            IoTGpioSetOutputVal(LED_G_GPIO_HANDLE, IOT_GPIO_VALUE0);
            IoTGpioSetOutputVal(LED_B_GPIO_HANDLE, IOT_GPIO_VALUE0);
        }

        last_state = state;
    }