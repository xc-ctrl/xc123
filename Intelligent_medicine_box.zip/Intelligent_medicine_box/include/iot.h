#ifndef _IOT_H_
#define _IOT_H_

#include <stdbool.h>

typedef struct
{
    double illumination;
    double temperature;
    double humidity;
    bool smoke_state;
    int medicine_state;
    
} e_iot_data;

#define IOT_CMD_LIGHT_ON 0x01
#define IOT_CMD_LIGHT_OFF 0x02

#define IOT_CMD_YELLOW_ON 0x03
#define IOT_CMD_YELLOW_OFF 0x04

#define IOT_CMD_BLUE_ON 0x05
#define IOT_CMD_BLUE_OFF 0x06

#define IOT_CMD_GREEN_ON 0x07
#define IOT_CMD_GREEN_OFF 0x08

#define IOT_CMD_ARRY 0x09

int wait_message();
void mqtt_init();
unsigned int mqtt_is_connected();
void send_msg_to_mqtt(e_iot_data *iot_data);

#endif // _IOT_H_