#ifndef __MEDICINE_BOX_EVENT_H__
#define __MEDICINE_BOX_EVENT_H__

#include "stdint.h"
#include "stdbool.h"

enum auto_command
{
    auto_state_on = 0x0001,
    auto_state_off,
};

enum light_command
{
    light_state_on = 0x0101,
    light_state_off,
};

enum motor_command
{
    motor_state_on = 0x0201,
    motor_state_off,
};

enum temperature_command
{
    temperature_get = 0x0301,
    humidity_get,
    illumination_get,
};



typedef enum event_type{

    event_key_press = 1,
    event_iot_cmd,
    event_su03t,

}event_type_t;


typedef struct event_info
{
    event_type_t event;

    union {
        uint8_t key_no;
        int iot_data;
        int su03t_data;
        //char arry_data[256];  //储存数组的值
        char arry_data;
    } data;
} event_info_t;

void medicine_box_event_init();
void medicine_box_event_send(event_info_t *event);
int medicine_box_event_wait(event_info_t *event,int timeoutMs);

#endif