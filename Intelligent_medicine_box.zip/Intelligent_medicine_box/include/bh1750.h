#ifndef __BH1750_H__
#define __BH1750_H__

void bh1750_init();
void bh1750_read_data(double *dat);

#endif /* _EEPROM_H_ */
/** @} */
