#ifndef __SHT30_H__
#define __SHT30_H__

void sht30_init(void);
void sht30_read_data(double *dat);

#endif /* __SHT30_H__ */
/** @} */