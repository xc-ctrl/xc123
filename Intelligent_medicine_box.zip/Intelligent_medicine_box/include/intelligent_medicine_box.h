#ifndef _INTELLIGENT_MEDICINE_BOX_H_
#define _INTELLIGENT_MEDICINE_BOX_H_
#include <stdbool.h>
#include <stdint.h>

void lcd_dev_init(void);
void sht30_proress(void *arg);
void mq2_init(void);
void mq2_read_data(double *dat);
void body_induction_dev_init();
void body_induction_lcd_express();
void medicine_key_process(int key_no);

void HW_INIT();
void lcd_load(void);
void lcd_show(void);
void i2c_dev_init(void);
void light_dev_init(void);
void light_set_state(bool state);

#endif
